package com.temp.mynotification;

public class NotifyContent {
    public static String content = "";
    public static String title = "";
    public static String imageUrl = "";
    public static String Url = "";
}//END OF CLASS
